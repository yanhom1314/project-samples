# Demo

---

## Normal usage

````javascript
seajs.use('index', function(jqgrid) {

});
````
